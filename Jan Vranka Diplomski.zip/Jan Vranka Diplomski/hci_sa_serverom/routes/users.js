var express = require('express');
var app = express();
var router = express.Router();

var UsersModel = require('./../models/users');

router.get('/', async (req, res) => {
    let users = await UsersModel.find({});
    
    return res.send(users);
});

module.exports = router;