var express = require('express');
var app = express();
var router = express.Router();

var ProductsModel = require('./../models/products');

router.get('/', async (req, res) => {
    let products = await ProductsModel.find({});
    
    return res.send(products);
});

router.put('/:id', async (req, res) => {
    let product_id = req.params.id;
    let body = req.body;

    let result = await ProductsModel.findByIdAndUpdate(product_id, body);

    return res.send(result);
});

module.exports = router;