Postavljanje pocetnih podataka na novu bazu:

    $ node initialize_data.js

Pokretanje servera:

    $ node app.js