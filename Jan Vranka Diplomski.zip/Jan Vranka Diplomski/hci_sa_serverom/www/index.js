(function () {
    var app = angular.module("Store", ["ui.bootstrap"]);

    // var products = [{
    //         "naziv": "Ares Konfiguracija",
    //         "cena": 100000,
    //         "valuta": "RSD",
    //         "stanje": 3,
    //         "slika": "img/areskonfiguracija.jpg",
    //         "opis": "Gotova konfiguracija",
    //         "grupa": 1
    //     },
    //     {
    //         "naziv": "Zeus Konfiguracija",
    //         "cena": 95000,
    //         "valuta": "RSD",
    //         "stanje": 2,
    //         "slika": "img/zeuskonfiguracija.jpg",
    //         "opis": "Gotova konfiguracija",
    //         "grupa": 1
    //     },
    //     {
    //         "naziv": "Layla Konfiguracija",
    //         "cena": 115000,
    //         "valuta": "RSD",
    //         "stanje": 3,
    //         "slika": "img/layla2.jpg",
    //         "opis": "Gotova konfiguracija",
    //         "grupa": 1
    //     },
    //     {
    //         "naziv": "AMD Vega 64",
    //         "cena": 102000,
    //         "valuta": "RSD",
    //         "stanje": 4,
    //         "slika": "img/vega645.jpg",
    //         "opis": "Graficka kartica",
    //         "grupa": 2
    //     },
    //     {
    //         "naziv": "Nvidia RTX 2080ti",
    //         "cena": 212000,
    //         "valuta": "RSD",
    //         "stanje": 1,
    //         "slika": "img/2080ti.png",
    //         "opis": "Graficka kartica",
    //         "grupa": 2

    //     },
    //     {
    //         "naziv": "Intel i9 9900k",
    //         "cena": 250000,
    //         "valuta": "RSD",
    //         "stanje": 5,
    //         "slika": "img/i9990k.jpg",
    //         "opis": "Procesor",
    //         "grupa": 3
    //     },
    //     {
    //         "naziv": "AMD Threadripper 2950",
    //         "cena": 120000,
    //         "valuta": "RSD",
    //         "stanje": 8,
    //         "slika": "img/2950x4.jpg",
    //         "opis": "Procesor",
    //         "grupa": 3
    //     }
    // ];

    // var users = [
    //     { "name": "korisnik", "password": "korisnik123", "type": 0 },
    //     { "name": "admin", "password": "admin123", "type": 1 }
    // ];

    // var products = [];
    // var users = [];

    app.controller("StoreController", function ($scope, $uibModal, $http) {
        $scope.products = [];
        $scope.users = [];
        $scope.selectedItem = null;
        $scope.newItem = {
            naziv: '',
            cena: '',
            stanje: '',
            grupa: '',
            valuta: 'RSD'
        };

        $http({
            method: 'GET',
            url: 'http://localhost:8080/products'
        }).then(function successCallback(response) {
            $scope.products = response.data;
            $scope.filteredProducts = $scope.products;
        }, function errorCallback(response) {
            console.log(response);
        });

        $http({
            method: 'GET',
            url: 'http://localhost:8080/users'
        }).then(function successCallback(response) {
            console.log(response.data);
            $scope.users = response.data;
        }, function errorCallback(response) {
            console.log(response);
        });

        $scope.groups = [
            { "id": 1, "name": "Gotove konfiguracije" },
            { "id": 2, "name": "Graficke kartice" },
            { "id": 3, "name": "Procesori" },
            { "id": 0, "name": "Sve" }
        ];

        // $scope.filteredProducts = $scope.products;

        $scope.searchText = "";
        $scope.search = function () {
            $scope.filteredProducts = [];

            if ($scope.searchText.length == 0) {
                $scope.filteredProducts = $scope.products;
            } else {
                for (var item of $scope.products) {
                    if (item.naziv.toLowerCase().match($scope.searchText.toLowerCase())) {
                        $scope.filteredProducts.push(item);
                    }
                }
            }
        };

        $scope.groupSearch = function (search) {
            $scope.filteredProducts = [];

            if (search == 0) {
                $scope.filteredProducts = $scope.products;
            } else {
                for (var item of $scope.products) {
                    if (item.grupa === search) {
                        $scope.filteredProducts.push(item);
                    }
                }
            }
        };

        $scope.logout = function () {
            $scope.loggedIn = false;
            $scope.user = [];
            $scope.cart = [];
        };


        // $scope.users = $scope.us;

        $scope.user = {};
        $scope.loggedIn = false;
        $scope.login = function (login) {
            for (user of $scope.users) {
                if (login.user == user.name && login.password == user.password) {
                    $scope.loggedIn = true;
                    $scope.user = user;
                    $scope.closeModal();
                    login.user = "";
                    login.password = "";
                    login.errorMessage = "";
                    return;
                }
            }
            login.errorMessage = "Niste dobro uneli podatke.";
        };

        $scope.openLoginModal = function () {
            $scope.modalInstance = $uibModal.open({
                templateUrl: 'loginModal.tmpl.html',
                scope: $scope
            });
        };

        $scope.register = function (register) {
            var user = { "name": register.user, "password": register.password };
            $scope.users.push(user);
            //upis za bazu
            register.errorMessage = "Uspesno ste se registrovali sa korisnickim imenom " + register.user + " i lozinkom " + register.password;

        }

        $scope.openRegisterModal = function () {
            $scope.modalInstance = $uibModal.open({
                templateUrl: 'registerModal.tmpl.html',
                scope: $scope
            });
        };

        $scope.cart = [];
        $scope.cartPrice = 0;
        $scope.addToCart = function (item) {
            if ($scope.loggedIn == false)
                return $scope.openInfoModal("Greska: Morate biti prijavljeni da bi ste kupovali.");
            if (item.stanje < 1)
                return $scope.openInfoModal("Nema toliko na stanju.");

            var cartItem = angular.copy(item);

            for (var i of $scope.cart) {
                if (i.naziv == item.naziv) {
                    if (i.stanje < item.stanje) {
                        i.stanje++;
                        $scope.cartPrice += i.cena;
                        return;
                    } else {
                        return $scope.openInfoModal("Nema toliko na stanju.");
                    }
                }
            }

            cartItem.stanje = 1;
            $scope.cartPrice += cartItem.cena;
            $scope.cart.push(cartItem);
        };

        $scope.removeFromCart = function (item) {
            $scope.cartPrice -= item.cena;

            if (item.stanje == 1)
                return $scope.cart.splice($scope.cart.indexOf(item), 1);

            item.stanje--;
        };



        $scope.openCartModal = function () {
            if ($scope.loggedIn == false)
                return $scope.openInfoModal("Greska: Morate biti prijavljeni da bi ste kupovali.");

            $scope.modalInstance = $uibModal.open({
                templateUrl: 'cartModal.tmpl.html',
                scope: $scope
            });
        };

        $scope.itemToChange = null;

        $scope.change = function (item) {
            console.log("TESTES");
            $scope.itemToChange = item;
            $scope.openChangeItemModal();
        };

        $scope.saveEditItem = function () {
            console.log($scope.products);

            $http({
                method: 'PUT',
                url: 'http://localhost:8080/products/' + $scope.itemToChange._id,
                data: $scope.itemToChange
            }).then(function successCallback(response) {
                console.log(response.data);

                $scope.closeModal();
            }, function errorCallback(response) {
                console.log(response);
            });
        };

        $scope.deleteItem = function () {
            let index = -1;

            for (let i = 0; i < $scope.products.length; i++) {
                console.log($scope.products[i]._id === $scope.itemToChange._id);
                if ($scope.products[i]._id === $scope.itemToChange._id) {
                    index = i;
                }
            }

            if (index !== -1) {
                $scope.products.splice(index, 1);
                alert("Proizvod uspesno obrisan");
            }
        }

        $scope.openChangeItemModal = function () {
            $scope.modalInstance = $uibModal.open({
                templateUrl: 'changeItemModal.tmpl.html',
                scope: $scope,
                itemToChange: function () {
                    return $scope.itemToChange;
                }
            });
        }

        $scope.openInfoModal = function (message) {
            $scope.modalInstance = $uibModal.open({
                templateUrl: 'infoModal.tmpl.html',
                scope: $scope,
                controller: function ($scope) {
                    $scope.modalMessage = message;
                }
            });
        };

        $scope.openProductModal = function (item) {
            $scope.modalInstance = $uibModal.open({
                templateUrl: 'productDetailModal.tmpl.html',
                scope: $scope,
                controller: function ($scope) {
                    $scope.selectedItem = item;
                }
            });
        };

        $scope.closeModal = function () {
            $scope.modalInstance.dismiss();
        };

        $scope.productDetail = function (item) {
            console.log(item);
            $scope.openProductModal(item)
        }

        $scope.opetAddProductModal = function () {

            if ($scope.loggedIn == false)
                return $scope.openInfoModal("Greska: Morate biti prijavljeni da bi ste kupovali.");

            $scope.modalInstance = $uibModal.open({
                templateUrl: 'newItemModal.tmpl.html',
                scope: $scope

            });
        }

        $scope.addNewItem = function () {
            console.log($scope.newItem);
            $scope.products.push($scope.newItem);
        }

    });


}());