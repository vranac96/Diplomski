mongoose = require('mongoose');

var Schema = mongoose.Schema;

var UsersModelSchema = new Schema({
  name: String,
  password: String,
  type: Number
});

// Compile model from schema
var UsersModel = mongoose.model('users', UsersModelSchema );

module.exports = UsersModel;