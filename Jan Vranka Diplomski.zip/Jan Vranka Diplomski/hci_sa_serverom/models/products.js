mongoose = require('mongoose');

var Schema = mongoose.Schema;

var ProductsModelSchema = new Schema({
  naziv: String,
  cena: Number,
  valuta: String,
  stanje: Number,
  slika: String,
  opis: String,
  grupa: Number
});

// Compile model from schema
var ProductsModel = mongoose.model('products', ProductsModelSchema );

module.exports = ProductsModel;