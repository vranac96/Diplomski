var products = [{
    "naziv": "Ares Konfiguracija",
    "cena": 100000,
    "valuta": "RSD",
    "stanje": 3,
    "slika": "img/areskonfiguracija.jpg",
    "opis": "Gotova konfiguracija",
    "grupa": 1
},
{
    "naziv": "Zeus Konfiguracija",
    "cena": 95000,
    "valuta": "RSD",
    "stanje": 2,
    "slika": "img/zeuskonfiguracija.jpg",
    "opis": "Gotova konfiguracija",
    "grupa": 1
},
{
    "naziv": "Layla Konfiguracija",
    "cena": 115000,
    "valuta": "RSD",
    "stanje": 3,
    "slika": "img/layla2.jpg",
    "opis": "Gotova konfiguracija",
    "grupa": 1
},
{
    "naziv": "AMD Vega 64",
    "cena": 102000,
    "valuta": "RSD",
    "stanje": 4,
    "slika": "img/vega645.jpg",
    "opis": "Graficka kartica",
    "grupa": 2
},
{
    "naziv": "Nvidia RTX 2080ti",
    "cena": 212000,
    "valuta": "RSD",
    "stanje": 1,
    "slika": "img/2080ti.png",
    "opis": "Graficka kartica",
    "grupa": 2

},
{
    "naziv": "Intel i9 9900k",
    "cena": 250000,
    "valuta": "RSD",
    "stanje": 5,
    "slika": "img/i9990k.jpg",
    "opis": "Procesor",
    "grupa": 3
},
{
    "naziv": "AMD Threadripper 2950",
    "cena": 120000,
    "valuta": "RSD",
    "stanje": 8,
    "slika": "img/2950x4.jpg",
    "opis": "Procesor",
    "grupa": 3
}
];

var users = [
    { "name": "korisnik", "password": "korisnik123", "type": 0 },
    { "name": "admin", "password": "admin123", "type": 1 }
];


var mongoose = require('mongoose');
var ProductsModel = require('./models/products');
var UsersModel = require('./models/users');

var mongoDB = 'mongodb://localhost:27017/jv_company';
mongoose.connect(mongoDB, { useNewUrlParser: true });

var db = mongoose.connection;

db.on('error', console.error.bind(console, 'MongoDB connection error:'));

(async function() {
    for (let product of products) {
        await ProductsModel.create(product);
    }

    console.log("Products inserted!");
})();

(async function() {
    for (let user of users) {
        await UsersModel.create(user);
    }

    console.log("Users inserted!");
})();