
var
    mongoose = require('mongoose'),
    cors = require('cors'),
    express = require('express'),
    productsRoute = require('./routes/products'),
    usersRoute = require('./routes/users'),
    app = module.exports = express();

app.set('port', 8080);

app.use(cors());

app.use(express.static('www'));
app.use('/depends', express.static(__dirname + '/node_modules/'));

app.use(express.json());

// Routes
app.use('/products', productsRoute);
app.use('/users', usersRoute);


var mongoDB = 'mongodb://localhost:27017/jv_company';
mongoose.connect(mongoDB, { useNewUrlParser: true });

var db = mongoose.connection;

db.on('error', console.error.bind(console, 'MongoDB connection error:'));

app.listen(app.get('port'));

console.log("App started on port: " + app.get('port'));